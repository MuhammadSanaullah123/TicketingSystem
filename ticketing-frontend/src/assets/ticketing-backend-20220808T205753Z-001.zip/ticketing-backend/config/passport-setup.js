const passport = require('passport')
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const User = require('../models/User')

passport.serializeUser((user, done) => {
    done(null, user);
});
  
passport.deserializeUser((user, done) => {
    done(null, user);
});

passport.use(new GoogleStrategy({
    callbackURL: "/api/auth/google/redirect",
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET
}, async(accessToken, refreshToken, profile, done) => {
    console.log(profile)
    const user = await User.findOne({ googleId: profile.id })
    if (user) {
        done(null, user)
    } else {
        const result = await new User({
            username: profile.displayName,
            googleId: profile.id,
            email:profile.emails[0].value
        }).save()
        done(null, result)
    }
}));
