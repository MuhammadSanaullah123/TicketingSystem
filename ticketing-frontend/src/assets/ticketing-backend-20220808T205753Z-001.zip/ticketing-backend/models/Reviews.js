const mongoose = require('mongoose')

const ReviewSchema = new mongoose.model({
    rating: {
        type:Number
    },
    review: {
        type:String
    }
})

const Reviews = new mongoose.model("Reviews",ReviewSchema)
module.exports = Reviews;