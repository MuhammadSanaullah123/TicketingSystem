const catchAsync = require('../utils/catchAsync')
const AppError = require('../utils/appError')
const Operator = require('../models/Operator');
const User = require('../models/User');
const moment = require('moment')
const Booking = require('../models/Bookings');
const Coupon = require('../models/Coupons');

exports.getOperatorDetails = catchAsync(async (req, res, next) => {
    const operator = await Operator.findById(req.params.id).populate('busId').populate('userId').select('-password');
    if (!operator) {
        return next(
            new AppError('Operator Not Found', 404)
        )
    }
    res.json({ success: true, operator })
})

exports.setOperatorDetails = catchAsync(async (req, res, next) => {
    const { name, address, contact } = req.body
    let user = await User.findById(req.user.id)
    const newOperator = new Operator({
        userId: req.user.id,
        address,
        name,
        contact,
    })
    user.role = 'operator';
    await user.save()
    await newOperator.save();
    res.json({ status: true, message: "Operators Details Registered Succesfully." })
})

exports.getRecentBookings = catchAsync(async (req, res, next) => {
    const { busType, date, routeFrom, routeTo } = req.body
    const operator = await Operator.findOne({ userId: req.user.id })
    let queryObject = { operatorId: operator.id };
    // if (bus)
    const bookings = await Booking.find(queryObject).populate('busId').populate('userId')
    for (let i = 0; i < bookings.length; i++) {
        if (moment(bookings[i].createdAt).day == moment(Date.now()).day) {
            todaySale += (+bookings[i].price)
        }
    }
    res.json({ message: "Success", recentBookings: bookings.reverse() })
})

exports.getSalesDetails = catchAsync(async (req, res, next) => {
    const operator = await Operator.findOne({ userId: req.user.id })
    if (!operator) {
        return next(
            new AppError('Try Logging In With Correct Operator Id ')
        )
    }
    const bookings = await Booking.find({ operatorId: operator.id }).populate('busId').populate('userId')
    let todaySale = 0;
    let monthSale = 0;
    let totalSale = 0;
    for (let i = 0; i < bookings.length; i++) {
        totalSale += Number(bookings[i].price)
        if (moment(bookings[i].createdAt).day == (moment(Date.now()).day)) {
            todaySale += Number(bookings[i].price)
        }
        if (moment(bookings[i].createdAt).month() == moment(Date.now()).month()) {
            monthSale += Number(bookings[i].price)
        }
    }
    res.json({ todaySale, monthSale, totalSale })
})

exports.getCustomerDetails = catchAsync(async (req, res, next) => {
    const { civilianId, bookingId, name } = req.body;
    let queryObject = {}
    if (civilianId) queryObject.civilianId = civilianId;
    if (bookingId) queryObject.bookingId = bookingId;
    if (name) queryObject.name = name;
    let customers = []
    const operator = await User.findById(req.user.id)
    const bookings = await Booking.find({ operatorId: operator.id }).populate('userId')
    for (let i = 0; i < bookings.length; i++) {
        customers[i] = bookings[i].userId
        if (customers[i].username == queryObject.name) {
            return res.json({ customers: customers[i] })
        }
        if (customers[i].civilianId == queryObject.civilianId) {
            return res.json({ customers: customers[i] })
        }
        if (customers[i].bookingId == queryObject.bookingId) {
            return res.json({ customers: customers[i] })
        }
    }
    res.json({ customers })
})

exports.getBookingDetails = catchAsync(async (req, res, next) => {
    const { phone, status, days } = req.body
    const operator = await Operator.findOne({ userId: req.user.id })
    const bookings = await Booking.find({ operatorId: operator.id }).populate('busId').populate('userId')
    let startDate = moment(Date.now()).subtract(days, 'days')
    let booking = []
    if (phone && !status && !days) {
        booking = bookings.filter(p => { if (p.userId.phone == phone) return p })
    }
    if (phone && status && !days) {
        booking = bookings.filter(p => { if (p.userId.phone == phone && p.busId.status == status) return p })
    }
    if (phone && status && days) {
        booking = bookings.filter(p => { if (p.userId.phone == phone && p.busId.status == status && startDate.diff(moment(p.createdAt), 'hours') < 0) return p })
    }
    if (phone && !status && days) {
        booking = bookings.filter(p => { if (p.userId.phone == phone && startDate.diff(moment(p.createdAt), 'hours') < 0) return p })
    }
    if (!phone && !status && days) {
        booking = bookings.filter(p => { if (startDate.diff(moment(p.createdAt), 'hours') < 0) return p })
    }
    if (!phone && status && !days) {
        booking = bookings.filter(p => { if (p.busId.status == status) return p })
    }
    res.json({ booking, length: booking.length })
})

exports.addCoupon = catchAsync(async (req, res, next) => {
    const { name, code, validity, discount, busType } = req.body;
    if (!(name && code && discount)) {
        return next(
            new AppError('Provide the Necessary Fields', 400)
        )
    }
    const user = await User.findById(req.user.id)
    const operator = await Operator.findOne({ userId: user.id })
    const newCoupon = new Coupon({
        operatorId: operator.id,
        name,
        image: req.file.path,
        code,
        validity,
        discount,
        busType
    })
    const savedCoupon = await newCoupon.save()
    res.json({ success: true, message: "Coupon Created Succesfully", coupon: savedCoupon })
})

exports.getCoupon = catchAsync(async (req, res, next) => {
    const user = await User.findById(req.user.id)
    const operator = await Operator.findOne({ userId: user.id })
    const coupons = await Coupon.find({ operatorId: operator.id })
    res.json({ success: true, coupons })
})

exports.deleteCoupon = catchAsync(async (req, res, next) => {
    const deletedCoupon = await Coupon.findByIdAndRemove(req.params.id);
    if (!deletedCoupon) {
        return next(
            new AppError('Invalid Coupon Id Provided', 400)
        )
    }
    res.json({ success: true, deletedCoupon })
})

exports.updateCoupon = catchAsync(async (req, res, next) => {
    const { name, code, validity, discount, busType } = req.body;
    const updatedObject = {
        name, code, validity, discount, busType, image: req.file.path
    }
    const updatedCoupon = await Coupon.findByIdAndUpdate(req.params.id, updatedObject);
    if (!updatedCoupon) {
        return next(
            new AppError('Invalid Coupon Id Provided', 400)
        )
    }
    res.json({ success: true, updatedCoupon })
})

exports.getBuses = catchAsync(async (req, res, next) => {
    const user = await User.findById(req.user.id)
    const operator = await Operator.findOne({ userId: user.id }).populate('busId')
    if (!operator) {
        return next(
            new AppError('Invalid Operator', 400)
        )
    }
    const buses = operator.busId;
    res.json({ buses })
})