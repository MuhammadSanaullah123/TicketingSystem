const router = require('express').Router()
const passport = require('passport')
const checkAuth = require('../middlewares/checkAuth');
const userController = require('../controller/userController');
const restrictTo = require('../middlewares/restrictTo');
const authController = require('../controller/authController')

router
    .route("/login")
    .post(userController.loginUser)

router
    .route("/createUser")
    .post(userController.createUser)

router
    .route("/logout")
    .get(checkAuth, userController.logoutUser)

router
    .route("/updateUser/:id")
    .patch(checkAuth, userController.updateUser)

router
    .route("/removeUser/:id")
    .delete(checkAuth, restrictTo('admin'), userController.removeUser)

router
    .route("/getUser")
    .get(checkAuth, userController.getUser)


router.get('/google', passport.authenticate('google', {
    scope: ['profile', 'email']
}))

router
    .route("/google/redirect")
    .get(passport.authenticate('google'), userController.setCookie)

router
    .route('/forgotPassword')
    .post(authController.forgotPassword)

router
    .route('/resetPassword')
    .post(authController.resetPassword)


router
    .route('/changeRole/:id')
    .patch(checkAuth, restrictTo('admin'), authController.changeRole)

module.exports = router