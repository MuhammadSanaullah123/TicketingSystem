const router = require('express').Router()
const upload = require("../middlewares/multer");
const operatorController = require('../controller/operatorController')
const checkAuth = require('../middlewares/checkAuth')
const restrictTo = require('../middlewares/restrictTo')

router
    .route("/")
    .post(checkAuth, operatorController.setOperatorDetails)

router
    .route("/recentBookings")
    .post(checkAuth, restrictTo('operator'), operatorController.getRecentBookings)

router
    .route("/salesOverview")
    .get(checkAuth, restrictTo('operator'), operatorController.getSalesDetails)

router
    .route("/customer")
    .post(checkAuth, restrictTo('operator'), operatorController.getCustomerDetails)

router
    .route("/bus")
    .get(checkAuth, restrictTo('operator'), operatorController.getBuses)

router
    .route("/bookings")
    .post(checkAuth, restrictTo('operator'), operatorController.getBookingDetails)

router
    .route("/coupon")
    .post(checkAuth, restrictTo('operator'), upload.single('image'), operatorController.addCoupon)
    .get(checkAuth, restrictTo('operator'), operatorController.getCoupon)

router
    .route("/coupon/:id")
    .patch(checkAuth, restrictTo('operator'), upload.single('image'), operatorController.updateCoupon)
    .delete(checkAuth, restrictTo('operator'), operatorController.deleteCoupon)


router
    .route("/:id")
    .get(operatorController.getOperatorDetails)


module.exports = router