const router = require('express').Router()
const checkAuth = require('../middlewares/checkAuth')
const bookingController = require('../controller/bookingController')

router
    .route('/bookSeats')
    .post(checkAuth, bookingController.bookSeats)

router
    .route('/verifyPayment')
    .post(bookingController.verifySeats)

router
    .route('/myBookings')
    .get(checkAuth, bookingController.myBookings)

module.exports = router