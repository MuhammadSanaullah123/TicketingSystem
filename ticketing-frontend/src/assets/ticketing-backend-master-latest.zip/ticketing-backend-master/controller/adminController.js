const catchAsync = require('../utils/catchAsync')
const AppError = require('../utils/appError')
const User = require('../models/User');
const Bus = require('../models/Bus');
const moment = require('moment')
const Booking = require('../models/Bookings');
const Coupon = require('../models/Coupons');
const bcrypt = require('bcrypt')
const createToken = require('../utils/createToken')

exports.getAdminDetails = catchAsync(async (req, res, next) => {
    const admin = await User.findById(req.params.id).select('-password')
    if (!admin) {
        return next(
            new AppError('Admin Not Found', 404)
        )
    }
    res.json({ success: true, admin })
})

exports.setAdminDetails = catchAsync(async (req, res, next) => {
    const { username, phone, email, password, civilianId } = req.body;
    const checkMail = await User.find({ email })
    if (checkMail.length != 0) {
        return next(
            new AppError('Email Already Exists', 400)
        )
    }
    if (!(email && password)) {
        return next(
            new AppError('Please Provide Email and Password')
        )
    }
    const salt = await bcrypt.genSalt();
    const hashPass = await bcrypt.hash(password, salt);
    const newUser = new User({
        username,
        email,
        role: "admin",
        civilianId,
        phone,
        password: hashPass
    })
    await newUser.save();
    res.json({ status: true, message: "Admin Details Registered Succesfully." })
})

exports.loginAdmin = catchAsync(async (req, res, next) => {
    let success = false;
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
        return next(
            new AppError('User Not Exists', 404)
        )
    }
    const passCompare = await bcrypt.compare(password, user.password)
    if (!passCompare) {
        return next(
            new AppError('Try Logging In with Correct Credentials', 404)
        )
    }
    success = true;
    const authToken = createToken(user.id)
    res.cookie('auth', authToken)
    res.status(200).json({ success, authToken });
})

exports.getBuses = catchAsync(async (req, res, next) => {
    const Buses = await Bus.find();
    res.json({ success: true, Buses })
})

exports.getCustomer = catchAsync(async (req, res, next) => {
    const Customers = await User.find({ role: 'customer' });
    res.json({ success: true, Customers })
})

exports.getBookings = catchAsync(async (req, res, next) => {
    const { operatorName, status, days } = req.query
    const bookings = await Booking.find().populate('busId').populate('userId')
    let startDate = moment(Date.now()).subtract(days, 'days')
    let booking = []
    if (operatorName && !status && !days) {
        booking = bookings.filter(p => { if (p.name == operatorName) return p })
    }
    if (operatorName && status && !days) {
        booking = bookings.filter(p => { if (p.name == operatorName && p.busId.status == status) return p })
    }
    if (operatorName && status && days) {
        booking = bookings.filter(p => { if (p.name == operatorName && p.busId.status == status && startDate.diff(moment(p.createdAt), 'hours') < 0) return p })
    }
    if (operatorName && !status && days) {
        booking = bookings.filter(p => { if (p.name == operatorName && startDate.diff(moment(p.createdAt), 'hours') < 0) return p })
    }
    if (!operatorName && !status && days) {
        booking = bookings.filter(p => { if (startDate.diff(moment(p.createdAt), 'hours') < 0) return p })
    }
    if (!operatorName && status && !days) {
        booking = bookings.filter(p => { if (p.busId.status == status) return p })
    }
    if (!operatorName && !status && !days) {
        booking = bookings
    }
    res.json({ booking, length: booking.length })

})

exports.addCoupon = catchAsync(async (req, res, next) => {
    const { name, code, validity, discount, busType } = req.body;
    if (!(name && code && discount)) {
        return next(
            new AppError('Provide the Necessary Fields', 400)
        )
    }
    const newCoupon = new Coupon({
        name,
        image: req.file.path,
        code,
        validity,
        discount,
        busType
    })
    const savedCoupon = await newCoupon.save()
    res.json({ success: true, message: "Coupon Created Succesfully", coupon: savedCoupon })
})

exports.getCoupon = catchAsync(async (req, res, next) => {
    const coupons = await Coupon.find()
    res.json({ success: true, coupons })
})

exports.deleteCoupon = catchAsync(async (req, res, next) => {
    const deletedCoupon = await Coupon.findByIdAndRemove(req.params.id);
    if (!deletedCoupon) {
        return next(
            new AppError('Invalid Coupon Id Provided', 400)
        )
    }
    res.json({ success: true, deletedCoupon })
})

exports.updateCoupon = catchAsync(async (req, res, next) => {
    const { name, code, validity, discount, busType } = req.body;
    const updatedObject = {
        name, code, validity, discount, busType, image: req.file.path
    }
    const updatedCoupon = await Coupon.findByIdAndUpdate(req.params.id, updatedObject, { new: true });
    if (!updatedCoupon) {
        return next(
            new AppError('Invalid Coupon Id Provided', 400)
        )
    }
    res.json({ success: true, updatedCoupon })
})


exports.getRecentBookings = catchAsync(async (req, res, next) => {
    const { busType, date, routeFrom, routeTo } = req.body

    // if (bus)
    const bookings = await Booking.find().populate('busId').populate('userId')
    // for (let i = 0; i < bookings.length; i++) {
    //     if (moment(bookings[i].createdAt).day == moment(Date.now()).day) {
    //         todaySale += (+bookings[i].price)
    //     }
    // }
    res.json({ message: "Success", recentBookings: bookings.reverse() })
})

exports.getSalesDetails = catchAsync(async (req, res, next) => {
    const bookings = await Booking.find().populate('busId').populate('userId')
    let todaySale = 0;
    let monthSale = 0;
    let totalSale = 0;
    for (let i = 0; i < bookings.length; i++) {
        totalSale += Number(bookings[i].price)
        if (moment(bookings[i].createdAt).day() == (moment(Date.now()).day())) {
            todaySale += Number(bookings[i].price)
        }
        if (moment(bookings[i].createdAt).month() == moment(Date.now()).month()) {
            monthSale += Number(bookings[i].price)
        }
    }
    res.json({ todaySale, monthSale, totalSale })
})
