const Booking = require('../models/Bookings')
const catchAsync = require('../utils/catchAsync')
const AppError = require('../utils/appError')
const Bus = require('../models/Bus')
const moment = require('moment')

exports.bookSeats = catchAsync(async (req, res, next) => {
    const { busId, seats, phone, email,price, passengerDetails } = req.body
    const busDetails = await Bus.findById(busId)
    let isSeatBooked
    for (let i = 0; i < seats.length; i++) {
        isSeatBooked = busDetails.occupiedSeats.includes(seats[i])
        if (isSeatBooked) {
            return next(
                new AppError("Seat Is Already Occupied")
            )
        }
    }
    for (let i = 0; i < seats.length; i++) {
        if (seats[i] > busDetails.totalSeats) {
            return next(
                new AppError("Seat Not Found")
            )
        }
    }
    if (!busId) {
        return next(
            new AppError("Please Provide The Bus Id.")
        )
    }
    if (seats.length === 0) {
        return next(
            new AppError("You Must Select Atleast One Seat.")
        )
    }
    if (passengerDetails.length < seats.length) {
        return next(
            new AppError("Fill The Details of All The Passengers.")
        )
    }
    const bookings = new Booking({
        busId,
        userId: req.user.id,
        operatorId: busDetails.operatorId,
        seats,
        price,
        phone,
        email,
        passengerDetails
    })
    busDetails.occupiedSeats = busDetails.occupiedSeats.concat(seats);
    busDetails.occupiedSeats.sort(function (a, b) {
        return a - b;
    });
    busDetails.availableSeats = busDetails.totalSeats - busDetails.occupiedSeats.length;
    await busDetails.save()
    const result = await bookings.save()
    res.json({ success: true, message: "Booking Details Registered", bookingDetails: result })
})

exports.verifySeats = catchAsync(async (req, res, next) => {
    // WebHooks Code will be Implemented here
})

exports.myBookings = catchAsync(async (req, res, next) => {
    const bookings = await Booking.find({ userId: req.user.id }).populate('busId');
    const pastBookings = bookings.filter(b => {
        const currentBus = b.busId
        let diff = moment().diff(moment(currentBus.date, 'DD-MM-YYYY'), "days")
        if (diff > 0) return b
    })
    const upcomingBookings = bookings.filter(b => {
        const currentBus = b.busId
        let diff = moment().diff(moment(currentBus.date, 'DD-MM-YYYY'), "days")
        if (diff < 0) return b
    })
    console.log(pastBookings)
    res.json({ success: true, pastBookings, upcomingBookings })
})