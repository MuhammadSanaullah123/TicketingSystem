const router = require('express').Router()
const upload = require("../middlewares/multer");
const adminController = require('../controller/adminController')
const checkAuth = require('../middlewares/checkAuth')
const restrictTo = require('../middlewares/restrictTo')


router
    .route("/createAdmin")
    .post(adminController.setAdminDetails)

router
    .route("/login")
    .post(adminController.loginAdmin)

router
    .route("/customer")
    .get(checkAuth, restrictTo('admin'), adminController.getCustomer)

router
    .route("/recentBookings")
    .post(checkAuth, restrictTo('admin'), adminController.getRecentBookings)

router
    .route("/salesOverview")
    .get(checkAuth, restrictTo('admin'), adminController.getSalesDetails)

router
    .route("/bus")
    .get(checkAuth, restrictTo('admin'), adminController.getBuses)

router
    .route("/bookings")
    .post(checkAuth, restrictTo('admin'), adminController.getBookings)

router
    .route("/coupon")
    .post(checkAuth, restrictTo('admin'), upload.single('image'), adminController.addCoupon)
    .get(checkAuth, restrictTo('admin'), adminController.getCoupon)

router
    .route("/coupon/:id")
    .patch(checkAuth, restrictTo('admin'), upload.single('image'), adminController.updateCoupon)
    .delete(checkAuth, restrictTo('admin'), adminController.deleteCoupon)

module.exports = router