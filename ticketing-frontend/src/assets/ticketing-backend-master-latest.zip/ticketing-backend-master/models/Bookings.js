const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
    busId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Bus'
    },
    operatorId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Operator'
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    transactionId: {
        type: String
    },
    paymentId: {
        type: String
    },
    seats: {
        type: [Number],
        required: true
    },
    email: {
        type: String,
        required: true
    },
    phone: {
        type: String
    },
    passengerDetails: [{
        name: {
            type: String,
            required: true
        },
        gender: {
            type: String,
            enum: ['male', 'female', 'others'],
            required: true
        },
        age: {
            type: Number
        }
    }],
    price: {
        type: Number
    },
    isPaymentDone: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
})

const Booking = new mongoose.model("Booking", bookingSchema)
module.exports = Booking;