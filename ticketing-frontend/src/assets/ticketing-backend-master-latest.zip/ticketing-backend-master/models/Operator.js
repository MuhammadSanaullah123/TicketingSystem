const mongoose = require('mongoose')

const operatorSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },
    name: {
        type: String,
        required: true
    },
    address: {
        type: String
    },
    contact: {
        type: String,
        required: true
    },
    busId: {
        type: [mongoose.Schema.Types.ObjectId],
        ref: "Bus"
    }
})

const Operator = new mongoose.model("Operator", operatorSchema)
module.exports = Operator;