const mongoose = require('mongoose')

const BusSchema = new mongoose.Schema({
    operatorId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Operator"
    },
    busNumber: {
        type: String,
        unique: true,
        required: true
    },
    busType: {
        type: String,
    },
    totalSeats: {
        type: Number,
        required: true
    },
    occupiedSeats: {
        type: [Number],
    },
    availableSeats: {
        type: Number
    },
    disabledSeats: {
        type: [Number],
    },
    price: {
        type: Number,
        required: true
    },
    departureTime: {
        type: String,
        required: true
    },
    arrivalTime: {
        type: String,
        required: true
    },
    image: {
        type: String
    },
    date: {
        type: String,
        required: true
    },
    status: {
        type: String
    },
    routeFrom: {
        type: String
    },
    routeTo: {
        type: String
    },
    rating: {
        type: [mongoose.Schema.Types.ObjectId],
        ref: 'Reviews'
    },
    bus_facilities: {
        type: [String]
    }
})

const Bus = new mongoose.model("Bus", BusSchema)
module.exports = Bus;