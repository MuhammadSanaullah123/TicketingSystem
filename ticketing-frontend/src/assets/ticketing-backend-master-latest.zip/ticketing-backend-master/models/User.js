const mongoose = require('mongoose')

const UserSchema = new mongoose.Schema({
    username: {
        type: String,
    },
    password: {
        type: String
    },
    walletId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Wallet'
    },
    email: {
        type: String,
        unique: true,
        required: true
    },
    phone: String,
    googleId: {
        type: String
    },
    address: {
        type: String
    },
    civilianId: {
        type: String
    },
    role: {
        type: String,
        enum: ['operator', 'customer', 'admin'],
        default: 'customer'
    },
    resetToken: {
        type: String,
        default: ""
    }
}, {
    timestamps: true
})

const User = new mongoose.model("User", UserSchema);

module.exports = User;